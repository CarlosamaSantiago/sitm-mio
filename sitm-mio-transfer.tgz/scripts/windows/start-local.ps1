param(
    [switch] $WithMap,
    [string] $IceHome = "C:\Program Files\ZeroC\Ice-3.7.11",
    [switch] $Clean
)

$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
Set-Location -LiteralPath $Root

function Require-File($Path, $Message) {
    if (-not (Test-Path -LiteralPath $Path)) {
        throw $Message
    }
}

function Write-JsonIfMissing($Path, $Content) {
    if (-not (Test-Path -LiteralPath $Path)) {
        $Parent = Split-Path -Parent $Path
        New-Item -ItemType Directory -Force -Path $Parent | Out-Null
        Set-Content -LiteralPath $Path -Value $Content -Encoding UTF8
    }
}

function ClassPath($ProjectPath) {
    return "nodes\$ProjectPath\build\runtime-libs\*;nodes\$ProjectPath\build\classes\java\main"
}

function New-NodeScript($Name, $Command) {
    $GeneratedDir = Join-Path $Root "scripts\windows\.generated"
    New-Item -ItemType Directory -Force -Path $GeneratedDir | Out-Null
    $ScriptPath = Join-Path $GeneratedDir "$Name.ps1"
    $Body = @"
`$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "$Root"
Write-Host "=== $Name ==="
$Command
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
"@
    Set-Content -LiteralPath $ScriptPath -Value $Body -Encoding UTF8
    return $ScriptPath
}

function Start-Node($Name, $Command) {
    $ScriptPath = New-NodeScript $Name $Command
    Start-Process powershell.exe -ArgumentList @(
        "-NoExit",
        "-ExecutionPolicy", "Bypass",
        "-File", "`"$ScriptPath`""
    )
}

Require-File "data\raw\lines-241-ActiveGT.csv" "Missing data\raw\lines-241-ActiveGT.csv"
Require-File "data\raw\datagrams-MiniPilot.csv" "Missing data\raw\datagrams-MiniPilot.csv"
Require-File (Join-Path $IceHome "bin\slice2java.exe") "slice2java.exe not found. Pass -IceHome with your ZeroC Ice folder."

$env:ICE_HOME = $IceHome

if ($Clean) {
    Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "queue\store", "lake", "analytics-db", "experiment"
}

Write-Host "==> Compiling node classes and runtime libraries"
gradle classes copyLibs --console=plain --quiet --no-daemon --project-cache-dir build\gradle-cache

Write-JsonIfMissing "admin\zone-mapping.example.json" '{"lineToZone":{"131":1,"140":1,"142":2,"217":3},"userToZone":{"admin":0,"ctrl-001":1,"ctrl-002":2}}'
Write-JsonIfMissing "admin\users.example.json" '[{"userId":"admin","passwordHash":"placeholder","role":"ADMIN","zoneId":0},{"userId":"ctrl-001","passwordHash":"placeholder","role":"CONTROLLER","zoneId":1}]'

Start-Node "01-data-lake" "java -cp '$(ClassPath "datacenter\data-lake")' edu.icesi.sitmmio.datalake.Main --port 10001 --store lake"
Start-Sleep -Milliseconds 500
Start-Node "02-queue" "java -cp '$(ClassPath "queue\datagram-queue")' edu.icesi.sitmmio.datagramqueue.Main --port 10010 --store queue\store"
Start-Sleep -Milliseconds 500
Start-Node "03-auth" "java -cp '$(ClassPath "server-admin\auth-service")' edu.icesi.sitmmio.authservice.Main --port 10040 --users admin\users.example.json --secret demo-secret --salt sitm-salt"
Start-Sleep -Seconds 2

Start-Node "04-analytics-store" "java -cp '$(ClassPath "datacenter\analytics-store")' edu.icesi.sitmmio.analyticsstore.Main --port 10060"
Start-Sleep -Milliseconds 500
Start-Node "05-session-context" "java -cp '$(ClassPath "datacenter\session-context")' edu.icesi.sitmmio.sessioncontext.Main --port 10030 --mapping admin\zone-mapping.example.json"
Start-Sleep -Milliseconds 500
Start-Node "06-event-bus" "java -cp '$(ClassPath "datacenter\datagram-event-bus")' edu.icesi.sitmmio.datagrameventbus.Main --port 10020"
Start-Sleep -Seconds 2

Start-Node "07-stream-processor" "java -cp '$(ClassPath "datacenter\stream-processor")' edu.icesi.sitmmio.streamprocessor.Main --queue-proxy 'DatagramQueue:default -h 127.0.0.1 -p 10010' --bus-proxy 'DatagramEventBus:default -h 127.0.0.1 -p 10020' --session-proxy 'SessionContextController:default -h 127.0.0.1 -p 10030' --consumers 2"
Start-Sleep -Milliseconds 500
Start-Node "08-batch-master" "java -cp '$(ClassPath "datacenter\batch-master")' edu.icesi.sitmmio.batchmaster.Main --port 10050 --routes data\raw\lines-241-ActiveGT.csv --timeout-s 120"
Start-Sleep -Seconds 2

Start-Node "09-ingestion-gateway" "java -cp '$(ClassPath "datacenter\ingestion-gateway")' edu.icesi.sitmmio.ingestiongateway.Main --routes data\raw\lines-241-ActiveGT.csv --queue-proxy 'DatagramQueue:default -h 127.0.0.1 -p 10010' --archive-proxy 'ArchiveService:default -h 127.0.0.1 -p 10001'"
Start-Sleep -Milliseconds 500
Start-Node "10-worker-w1" "java -cp '$(ClassPath "worker\batch-worker")' edu.icesi.sitmmio.batchworker.Main --worker-id w1 --port 10101 --lake lake --routes data\raw\lines-241-ActiveGT.csv --master-proxy 'BatchMaster:default -h 127.0.0.1 -p 10050'"
Start-Sleep -Milliseconds 500
Start-Node "11-worker-w2" "java -cp '$(ClassPath "worker\batch-worker")' edu.icesi.sitmmio.batchworker.Main --worker-id w2 --port 10102 --lake lake --routes data\raw\lines-241-ActiveGT.csv --master-proxy 'BatchMaster:default -h 127.0.0.1 -p 10050'"
Start-Sleep -Milliseconds 500
Start-Node "12-public-api" "java -cp '$(ClassPath "server-public-api\public-api");nodes\server-public-api\public-api\build\resources\main' edu.icesi.sitmmio.publicapi.Main --http-port 9090 --auth-proxy 'AuthService:default -h 127.0.0.1 -p 10040' --reports-proxy 'ReportProvider:default -h 127.0.0.1 -p 10060'"

if ($WithMap) {
    Start-Sleep -Seconds 2
    Start-Node "13-cco-client" "gradle :nodes:client-cco:cco-client:run --console=plain --no-daemon --project-cache-dir build\gradle-cache"
}

Write-Host ""
Write-Host "Started local V3 nodes in PowerShell windows."
Write-Host "Wait until logs say listening/registered, then run:"
Write-Host "  .\scripts\windows\start-sim.ps1"
Write-Host "  .\scripts\windows\run-r7.ps1"
Write-Host ""
Write-Host "To stop:"
Write-Host "  .\scripts\windows\stop-local.ps1"
