$ErrorActionPreference = "Continue"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
Set-Location -LiteralPath $Root

Get-CimInstance Win32_Process |
    Where-Object { $_.CommandLine -like "*edu.icesi.sitmmio*" } |
    ForEach-Object {
        Write-Host "Stopping PID $($_.ProcessId): $($_.Name)"
        Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
    }

Write-Host ""
Write-Host "To clean durable state:"
Write-Host '  Remove-Item -Recurse -Force -ErrorAction SilentlyContinue "queue\store", "lake", "analytics-db", "experiment"'
