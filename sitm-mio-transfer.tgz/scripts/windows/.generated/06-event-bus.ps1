﻿$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "C:\Icesi\IngesoftIV\Proyecto Ingesoft\sitm-mio"
Write-Host "=== 06-event-bus ==="
java -cp 'nodes\datacenter\datagram-event-bus\build\runtime-libs\*;nodes\datacenter\datagram-event-bus\build\classes\java\main' edu.icesi.sitmmio.datagrameventbus.Main --port 10020
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
