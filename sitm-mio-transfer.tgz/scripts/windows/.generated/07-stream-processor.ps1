﻿$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "C:\Icesi\IngesoftIV\Proyecto Ingesoft\sitm-mio"
Write-Host "=== 07-stream-processor ==="
java -cp 'nodes\datacenter\stream-processor\build\runtime-libs\*;nodes\datacenter\stream-processor\build\classes\java\main' edu.icesi.sitmmio.streamprocessor.Main --queue-proxy 'DatagramQueue:default -h 127.0.0.1 -p 10010' --bus-proxy 'DatagramEventBus:default -h 127.0.0.1 -p 10020' --session-proxy 'SessionContextController:default -h 127.0.0.1 -p 10030' --consumers 2
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
