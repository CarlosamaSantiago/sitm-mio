﻿$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "C:\Icesi\IngesoftIV\Proyecto Ingesoft\sitm-mio"
Write-Host "=== 01-data-lake ==="
java -cp 'nodes\datacenter\data-lake\build\runtime-libs\*;nodes\datacenter\data-lake\build\classes\java\main' edu.icesi.sitmmio.datalake.Main --port 10001 --store lake
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
