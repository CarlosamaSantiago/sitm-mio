﻿$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "C:\Icesi\IngesoftIV\Proyecto Ingesoft\sitm-mio"
Write-Host "=== 09-ingestion-gateway ==="
java -cp 'nodes\datacenter\ingestion-gateway\build\runtime-libs\*;nodes\datacenter\ingestion-gateway\build\classes\java\main' edu.icesi.sitmmio.ingestiongateway.Main --routes data\raw\lines-241-ActiveGT.csv --queue-proxy 'DatagramQueue:default -h 127.0.0.1 -p 10010' --archive-proxy 'ArchiveService:default -h 127.0.0.1 -p 10001'
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
