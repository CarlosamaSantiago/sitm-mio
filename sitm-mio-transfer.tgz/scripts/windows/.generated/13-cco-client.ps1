﻿$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "C:\Icesi\IngesoftIV\Proyecto Ingesoft\sitm-mio"
Write-Host "=== 13-cco-client ==="
gradle :nodes:client-cco:cco-client:run --console=plain --no-daemon --project-cache-dir build\gradle-cache
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
