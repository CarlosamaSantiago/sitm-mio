﻿$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "C:\Icesi\IngesoftIV\Proyecto Ingesoft\sitm-mio"
Write-Host "=== 10-worker-w1 ==="
java -cp 'nodes\worker\batch-worker\build\runtime-libs\*;nodes\worker\batch-worker\build\classes\java\main' edu.icesi.sitmmio.batchworker.Main --worker-id w1 --port 10101 --lake lake --routes data\raw\lines-241-ActiveGT.csv --master-proxy 'BatchMaster:default -h 127.0.0.1 -p 10050'
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
