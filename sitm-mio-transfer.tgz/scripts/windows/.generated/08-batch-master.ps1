﻿$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "C:\Icesi\IngesoftIV\Proyecto Ingesoft\sitm-mio"
Write-Host "=== 08-batch-master ==="
java -cp 'nodes\datacenter\batch-master\build\runtime-libs\*;nodes\datacenter\batch-master\build\classes\java\main' edu.icesi.sitmmio.batchmaster.Main --port 10050 --routes data\raw\lines-241-ActiveGT.csv --timeout-s 120
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
