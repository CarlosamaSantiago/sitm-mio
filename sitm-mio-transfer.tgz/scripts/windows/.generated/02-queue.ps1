﻿$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "C:\Icesi\IngesoftIV\Proyecto Ingesoft\sitm-mio"
Write-Host "=== 02-queue ==="
java -cp 'nodes\queue\datagram-queue\build\runtime-libs\*;nodes\queue\datagram-queue\build\classes\java\main' edu.icesi.sitmmio.datagramqueue.Main --port 10010 --store queue\store
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
