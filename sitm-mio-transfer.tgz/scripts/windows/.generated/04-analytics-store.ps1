﻿$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "C:\Icesi\IngesoftIV\Proyecto Ingesoft\sitm-mio"
Write-Host "=== 04-analytics-store ==="
java -cp 'nodes\datacenter\analytics-store\build\runtime-libs\*;nodes\datacenter\analytics-store\build\classes\java\main' edu.icesi.sitmmio.analyticsstore.Main --port 10060
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
