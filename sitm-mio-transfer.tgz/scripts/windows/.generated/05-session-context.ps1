﻿$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "C:\Icesi\IngesoftIV\Proyecto Ingesoft\sitm-mio"
Write-Host "=== 05-session-context ==="
java -cp 'nodes\datacenter\session-context\build\runtime-libs\*;nodes\datacenter\session-context\build\classes\java\main' edu.icesi.sitmmio.sessioncontext.Main --port 10030 --mapping admin\zone-mapping.example.json
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
