﻿$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "C:\Icesi\IngesoftIV\Proyecto Ingesoft\sitm-mio"
Write-Host "=== 12-public-api ==="
java -cp 'nodes\server-public-api\public-api\build\runtime-libs\*;nodes\server-public-api\public-api\build\classes\java\main;nodes\server-public-api\public-api\build\resources\main' edu.icesi.sitmmio.publicapi.Main --http-port 9090 --auth-proxy 'AuthService:default -h 127.0.0.1 -p 10040' --reports-proxy 'ReportProvider:default -h 127.0.0.1 -p 10060'
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
