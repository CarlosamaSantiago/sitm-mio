﻿$ErrorActionPreference = "Stop"
Set-Location -LiteralPath "C:\Icesi\IngesoftIV\Proyecto Ingesoft\sitm-mio"
Write-Host "=== 03-auth ==="
java -cp 'nodes\server-admin\auth-service\build\runtime-libs\*;nodes\server-admin\auth-service\build\classes\java\main' edu.icesi.sitmmio.authservice.Main --port 10040 --users admin\users.example.json --secret demo-secret --salt sitm-salt
Write-Host ""
Write-Host "Process finished. Press Enter to close."
[void][Console]::ReadLine()
