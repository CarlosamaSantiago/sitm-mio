param(
    [int] $Year = 2019,
    [int] $Month = 5
)

$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
Set-Location -LiteralPath $Root

New-Item -ItemType Directory -Force -Path "experiment" | Out-Null

$SourcePath = "experiment\RunR7.java"
$ClassPath = "contracts\build\runtime-libs\*;contracts\build\classes\java\main"

if (-not (Test-Path -LiteralPath "experiment\RunR7.class")) {
    $Source = @'
import com.zeroc.Ice.Communicator;
import com.zeroc.Ice.ObjectPrx;
import com.zeroc.Ice.Util;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class RunR7 {
    public static void main(String[] args) throws java.lang.Exception {
        int year = 2019, month = 5;
        if (args.length >= 2) {
            year = Integer.parseInt(args[0]);
            month = Integer.parseInt(args[1]);
        }

        try (Communicator c = Util.initialize(new String[0])) {
            ObjectPrx base = c.stringToProxy("BatchMaster:default -h 127.0.0.1 -p 10050");
            SITM.BatchMasterPrx master = SITM.BatchMasterPrx.checkedCast(base);
            if (master == null) {
                System.err.println("Invalid BatchMaster proxy");
                System.exit(1);
            }

            System.out.println();
            System.out.println("==================================================================");
            System.out.println("   V3 DISTRIBUTED - runMonth(" + year + ", " + month + ")");
            System.out.println("==================================================================");
            System.out.println("Dispatching to BatchMaster...");

            long t0 = System.currentTimeMillis();
            SITM.SpeedReport[] results = master.runMonth(year, month);
            long elapsed = System.currentTimeMillis() - t0;

            List<SITM.SpeedReport> sorted = new ArrayList<>(Arrays.asList(results));
            sorted.sort((a, b) -> Double.compare(b.averageSpeedKmH, a.averageSpeedKmH));

            int ok = 0, noData = 0;
            try (PrintWriter pw = new PrintWriter(new FileWriter("experiment/v3-results.csv"))) {
                pw.println("lineId,shortName,description,yearMonth,totalDistanceKm,totalTimeHours,averageSpeedKmH,validSegments,skippedSegments,status");
                for (SITM.SpeedReport r : sorted) {
                    pw.printf("%d,\"%s\",\"%s\",%04d-%02d,%.6f,%.9f,%.6f,%d,%d,%s%n",
                        r.lineId, r.shortName, r.description, r.year, r.month,
                        r.totalDistanceKm, r.totalTimeHours, r.averageSpeedKmH,
                        r.validSegments, r.skippedSegments, r.status);
                    if ("OK".equals(r.status)) ok++; else noData++;
                }
            }

            List<SITM.SpeedReport> okOnly = new ArrayList<>();
            for (SITM.SpeedReport r : sorted) if ("OK".equals(r.status)) okOnly.add(r);

            System.out.println();
            System.out.println("+-----------+------------+-----------+----------+--------------+");
            System.out.println("| lineId    | shortName  |  km/h     | segments | status       |");
            System.out.println("+-----------+------------+-----------+----------+--------------+");

            int show = Math.min(15, okOnly.size());
            for (int i = 0; i < show; i++) {
                SITM.SpeedReport r = okOnly.get(i);
                System.out.printf("| %-9d | %-10s | %8.4f  | %8d | %-12s |%n",
                    r.lineId, trunc(r.shortName, 10), r.averageSpeedKmH, r.validSegments, r.status);
            }
            if (okOnly.size() > 30) {
                System.out.println("|    ...    |    ...     |   ...     |   ...    |     ...      |");
                for (int i = okOnly.size() - 15; i < okOnly.size(); i++) {
                    SITM.SpeedReport r = okOnly.get(i);
                    System.out.printf("| %-9d | %-10s | %8.4f  | %8d | %-12s |%n",
                        r.lineId, trunc(r.shortName, 10), r.averageSpeedKmH, r.validSegments, r.status);
                }
            }
            System.out.println("+-----------+------------+-----------+----------+--------------+");

            System.out.println();
            System.out.printf("[V3] Total time:       %d ms%n", elapsed);
            System.out.printf("[V3] Processed routes: %d (OK: %d, NO_DATA: %d)%n", results.length, ok, noData);
            System.out.println("[V3] Output:           experiment/v3-results.csv");
        }
    }

    private static String trunc(String s, int n) {
        if (s == null) return "";
        return s.length() <= n ? s : s.substring(0, n);
    }
}
'@
    Set-Content -LiteralPath $SourcePath -Value $Source -Encoding UTF8
    javac -d experiment -cp $ClassPath $SourcePath
}

java -cp "experiment;$ClassPath" RunR7 $Year $Month

if ((Test-Path -LiteralPath "data\output\monolith-results.csv") -and (Test-Path -LiteralPath "experiment\v3-results.csv")) {
    Write-Host ""
    Write-Host "==================================================================="
    Write-Host " VERIFICATION AGAINST V1 ORACLE"
    Write-Host "==================================================================="
    $V1 = Get-Content "data\output\monolith-results.csv" | Where-Object { $_ -notmatch "^lineId" } | Sort-Object
    $V3 = Get-Content "experiment\v3-results.csv" | Where-Object { $_ -notmatch "^lineId" } | Sort-Object
    $Diff = Compare-Object $V1 $V3
    if (-not $Diff) {
        Write-Host " V3 == V1 (correctness verified)"
    } else {
        Write-Host " V3 differs from V1. First differences:"
        $Diff | Select-Object -First 10 | Format-Table -AutoSize
    }
    Write-Host "==================================================================="
}
