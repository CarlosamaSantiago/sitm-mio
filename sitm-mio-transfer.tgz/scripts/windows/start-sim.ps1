param(
    [string] $Dataset = "data\raw\datagrams-MiniPilot.csv"
)

$ErrorActionPreference = "Stop"
$Root = (Resolve-Path (Join-Path $PSScriptRoot "..\..")).Path
Set-Location -LiteralPath $Root

$ClassPath = "nodes\bus\bus-simulator\build\runtime-libs\*;nodes\bus\bus-simulator\build\classes\java\main"
java -cp $ClassPath edu.icesi.sitmmio.bussimulator.Main `
    --host 127.0.0.1 --port 10000 `
    --dataset $Dataset `
    --throttle-ms 0 --rate-multiplier 1.0
